﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree_part2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7 };

            ArvoreAVL arvore = new ArvoreAVL();

            foreach (int elemento in array)
            {
                arvore.Inserir(elemento);
                arvore.ImprimirArvore();
                Console.WriteLine("\n");

                int fatorBalanceamento = arvore.raiz.FatorBalanceamento();
                Console.WriteLine("Fator de Balanceamento: " + fatorBalanceamento);
                Console.WriteLine("-------------------------------------------------");
            }

            Console.ReadLine();
        }
    }
}
