﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree_part2
{
    internal class ArvoreAVL
    {
        public NoArvore raiz;

        public void Inserir(int dado)
        {
            raiz = InserirRecursivo(raiz, dado);
        }

        private NoArvore InserirRecursivo(NoArvore noAtual, int dado)
        {
            if (noAtual == null)
            {
                NoArvore novoNo = new NoArvore();
                novoNo.Dado = dado;
                return novoNo;
            }

            if (dado < noAtual.Dado)
            {
                noAtual.Esquerda = InserirRecursivo(noAtual.Esquerda, dado);
            }
            else if (dado > noAtual.Dado)
            {
                noAtual.Direita = InserirRecursivo(noAtual.Direita, dado);
            }

            AtualizarAltura(noAtual);
            return Balancear(noAtual);
        }

        private void AtualizarAltura(NoArvore no)
        {
            int alturaEsquerda = ObterAltura(no.Esquerda);
            int alturaDireita = ObterAltura(no.Direita);
            no.Altura = Math.Max(alturaEsquerda, alturaDireita) + 1;
        }

        private int ObterAltura(NoArvore no)
        {
            if (no == null)
            {
                return -1;
            }
            return no.Altura;
        }

        private NoArvore Balancear(NoArvore no)
        {
            if (FatorBalanceamento(no) > 1)
            {
                if (FatorBalanceamento(no.Esquerda) < 0)
                {
                    no.Esquerda = RotacionarEsquerda(no.Esquerda);
                }
                return RotacionarDireita(no);
            }

            if (FatorBalanceamento(no) < -1)
            {
                if (FatorBalanceamento(no.Direita) > 0)
                {
                    no.Direita = RotacionarDireita(no.Direita);
                }
                return RotacionarEsquerda(no);
            }

            return no;
        }

        private int FatorBalanceamento(NoArvore no)
        {
            if (no == null)
            {
                return 0;
            }
            return ObterAltura(no.Esquerda) - ObterAltura(no.Direita);
        }

        private NoArvore RotacionarEsquerda(NoArvore no)
        {
            NoArvore novoNo = no.Direita;
            no.Direita = novoNo.Esquerda;
            novoNo.Esquerda = no;

            AtualizarAltura(no);
            AtualizarAltura(novoNo);

            return novoNo;
        }

        private NoArvore RotacionarDireita(NoArvore no)
        {
            NoArvore novoNo = no.Esquerda;
            no.Esquerda = novoNo.Direita;
            novoNo.Direita = no;

            AtualizarAltura(no);
            AtualizarAltura(novoNo);

            return novoNo;
        }

        public void ImprimirArvore()
        {
            ImprimirArvoreRecursivo(raiz, "");
        }

        private void ImprimirArvoreRecursivo(NoArvore no, string espaco)
        {
            if (no == null)
            {
                return;
            }

            string espacoDireita = espaco + "   ";
            ImprimirArvoreRecursivo(no.Direita, espacoDireita);

            Console.WriteLine(espaco + "|-" + no.Dado);

            string espacoEsquerda = espaco + "   ";
            ImprimirArvoreRecursivo(no.Esquerda, espacoEsquerda);
        }
    }
}
