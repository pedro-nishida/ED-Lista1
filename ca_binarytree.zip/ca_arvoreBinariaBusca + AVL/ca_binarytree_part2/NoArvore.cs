﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree_part2
{
    internal class NoArvore
    {
        public int Dado { get; set; }
        public int Altura { get; set; }
        public NoArvore Esquerda { get; set; }
        public NoArvore Direita { get; set; }

        public int FatorBalanceamento()
        {
            int alturaEsquerda = ObterAltura(Esquerda);
            int alturaDireita = ObterAltura(Direita);

            return alturaEsquerda - alturaDireita;
        }

        private int ObterAltura(NoArvore no)
        {
            if (no == null)
            {
                return -1;
            }
            return no.Altura;
        }
    }
}
