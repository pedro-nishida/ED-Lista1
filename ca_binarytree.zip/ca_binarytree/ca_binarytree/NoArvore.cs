﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree
{
    internal class NoArvore
    {
        public int Dado { get; set; }
        public NoArvore Esquerda { get; set; }
        public NoArvore Direita { get; set; }
    }
}