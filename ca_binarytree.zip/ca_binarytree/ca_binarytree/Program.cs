﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArvoreBinaria arvore = new ArvoreBinaria();

            arvore.Inserir(10);
            arvore.Inserir(6);
            arvore.Inserir(14);
            arvore.Inserir(4);
            arvore.Inserir(8);
            arvore.Inserir(12);
            arvore.Inserir(16);
            //imprime a arvore
            arvore.ImprimirArvore();

            // 1) Função para retornar a alturada da árvore binária
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 1");
            int altura = arvore.ObterAlturaArvore();
            Console.WriteLine("Altura da árvore binária: " + altura);
            Console.ReadLine();

            // 2) Função para retornar a quantidade de nós da árvore binária
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 2");       
            int quantidadeNos = arvore.ObterQuantidadeNos();
            Console.WriteLine("Quantidade de nós: " + quantidadeNos);
            Console.ReadLine();

            // 2) Função para calcular o número de folhas em uma árvore binária
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 3");
            int quantidadeFolhas = arvore.ObterQuantidadeFolhas();
            Console.WriteLine("Quantidade de folhas: " + quantidadeFolhas);
            Console.ReadLine();

            // 4) Função para comparar se duas árvores binárias são iguais
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 4");
            Console.WriteLine("Testando com arvore identica");
            ArvoreBinaria igualArvore = new ArvoreBinaria();
            igualArvore.Inserir(10);
            igualArvore.Inserir(6);
            igualArvore.Inserir(14);
            igualArvore.Inserir(4);
            igualArvore.Inserir(8);
            igualArvore.Inserir(12);
            igualArvore.Inserir(16);

            bool saoIguais = arvore.SaoArvoresIguais(igualArvore);
            Console.WriteLine("As árvores são iguais? " + saoIguais);
            Console.ReadLine();

            Console.WriteLine("Testando com arvore diferente");
            ArvoreBinaria diferenteArvore = new ArvoreBinaria();
            diferenteArvore.Inserir(10);
            diferenteArvore.Inserir(6);
            diferenteArvore.Inserir(14);
            diferenteArvore.Inserir(4);
            diferenteArvore.Inserir(8);
            diferenteArvore.Inserir(12);
            diferenteArvore.Inserir(18);

            saoIguais = arvore.SaoArvoresIguais(diferenteArvore);
            Console.WriteLine("As árvores são iguais? " + saoIguais);
            Console.ReadLine();


            // 5) Função para obter o percurso pós-ordem de uma árvore binária
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 5");
            Console.Write("Percurso pós-ordem: ");
            arvore.ObterPercursoPosOrdem();
            Console.WriteLine();

            // 6) Pior caso para a altura de uma árvore binária de busca (ABB): 
            Console.WriteLine("------------------------------------------------------\nQUESTÃO 6");
            Console.WriteLine("Em uma árvore binária de busca desbalanceada, onde os nós são inseridos em ordem crescente ou decrescente, +\n" +
                "a altura da árvore será igual ao número de nós - 1. Por exemplo, se inserirmos os números 1, 2, 3, 4, 5, 6, 7\n" +
                "em uma árvore binária de busca, a altura será 6\n" +
                "em poucas palavras, o pior caso é a árvore virar uma lista encadeada crescente ou decrescente"
                );
            Console.WriteLine("\n Exemplo: CRESCENTE");
            ArvoreBinaria crescente = new ArvoreBinaria();
            crescente.Inserir(1);
            crescente.Inserir(2);
            crescente.Inserir(3);
            crescente.Inserir(4);
            crescente.Inserir(5);
            crescente.Inserir(6);
            crescente.Inserir(7);
            crescente.ImprimirArvore();
            Console.ReadLine();


            Console.WriteLine("\n Exemplo: DECRESCENTE");
            ArvoreBinaria decrescente = new ArvoreBinaria();
            decrescente.Inserir(7);
            decrescente.Inserir(6);
            decrescente.Inserir(5);
            decrescente.Inserir(4);
            decrescente.Inserir(3);
            decrescente.Inserir(2);
            decrescente.Inserir(1);
            decrescente.ImprimirArvore();
            Console.ReadLine();
        }
    }
}
