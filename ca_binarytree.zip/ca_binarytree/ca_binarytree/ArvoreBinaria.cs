﻿using ca_binarytree;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ca_binarytree
{
    internal class ArvoreBinaria
    {
        private NoArvore raiz;

        // Função para inserir um nó na árvore binária
        public void Inserir(int dado)
        {
            raiz = InserirRecursivo(raiz, dado);
        }

        private NoArvore InserirRecursivo(NoArvore noAtual, int dado)
        {
            if (noAtual == null)
            {
                NoArvore novoNo = new NoArvore();
                novoNo.Dado = dado;
                return novoNo;
            }

            if (dado < noAtual.Dado)
            {
                noAtual.Esquerda = InserirRecursivo(noAtual.Esquerda, dado);
            }
            else if (dado > noAtual.Dado)
            {
                noAtual.Direita = InserirRecursivo(noAtual.Direita, dado);
            }

            return noAtual;
        }

        // Função que retorna a quantidade de nós da árvore binária
        public int ObterQuantidadeNos()
        {
            return ContarNos(raiz);
        }

        private int ContarNos(NoArvore no)
        {
            if (no == null)
            {
                return 0;
            }

            int nosEsquerda = ContarNos(no.Esquerda);
            int nosDireita = ContarNos(no.Direita);

            return nosEsquerda + nosDireita + 1;
        }

        // Função que calcula o número de folhas em uma árvore binária
        public int ObterQuantidadeFolhas()
        {
            return ContarFolhas(raiz);
        }

        private int ContarFolhas(NoArvore no)
        {
            if (no == null)
            {
                return 0;
            }

            if (no.Esquerda == null && no.Direita == null)
            {
                return 1;
            }

            int folhasEsquerda = ContarFolhas(no.Esquerda);
            int folhasDireita = ContarFolhas(no.Direita);

            return folhasEsquerda + folhasDireita;
        }

        // Função que compara se duas árvores binárias são iguais
        public bool SaoArvoresIguais(ArvoreBinaria outraArvore)
        {
            return CompararArvores(raiz, outraArvore.raiz);
        }

        private bool CompararArvores(NoArvore noAtual, NoArvore outroNo)
        {
            if (noAtual == null && outroNo == null)
            {
                return true;
            }

            if (noAtual == null || outroNo == null)
            {
                return false;
            }

            if (noAtual.Dado != outroNo.Dado)
            {
                return false;
            }

            bool esquerdaIgual = CompararArvores(noAtual.Esquerda, outroNo.Esquerda);
            bool direitaIgual = CompararArvores(noAtual.Direita, outroNo.Direita);

            return esquerdaIgual && direitaIgual;
        }

        // Função que retorna o percurso pós-ordem de uma árvore binária
        public void ObterPercursoPosOrdem()
        {
            PercursoPosOrdem(raiz);
        }

        private void PercursoPosOrdem(NoArvore no)
        {
            if (no == null)
            {
                return;
            }

            PercursoPosOrdem(no.Esquerda);
            PercursoPosOrdem(no.Direita);
            Console.Write(no.Dado + " ");
        }

        // Função que retorna a altura da árvore binária
        public int ObterAlturaArvore()
        {
            return CalcularAltura(raiz);
        }

        private int CalcularAltura(NoArvore no)
        {
            if (no == null)
            {
                return 0;
            }

            int alturaEsquerda = CalcularAltura(no.Esquerda);
            int alturaDireita = CalcularAltura(no.Direita);

            return Math.Max(alturaEsquerda, alturaDireita) + 1;
        }

        public void ImprimirArvore()
        {
            ImprimirArvoreRecursivo(raiz, "");
        }

        private void ImprimirArvoreRecursivo(NoArvore no, string espaco)
        {
            if (no == null)
            {
                return;
            }

            string espacoDireita = espaco + "   ";
            ImprimirArvoreRecursivo(no.Direita, espacoDireita);

            Console.WriteLine(espaco + "|-" + no.Dado);

            string espacoEsquerda = espaco + "   ";
            ImprimirArvoreRecursivo(no.Esquerda, espacoEsquerda);
        }
    }

}

